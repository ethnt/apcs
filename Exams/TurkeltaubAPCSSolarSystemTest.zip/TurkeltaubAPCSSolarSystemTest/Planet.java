/**
	Java representation of a planet.
	author: Ethan Turkeltaub
	version: 0.1.0
**/

public class Planet {

	/*
	 * Instance variables
	 */
	
	private String name;
	private double diameter;
	private double mass;
	private static final double G = 6.674E-11;
	
	
	/*
	 * Constructors
	 */

	public Planet() {
		name = "Earth";
		diameter = 12756.0;
		mass = 5.97E-11;
	}

	public Planet(String inName, double inDiameter, double inMass) {
		name = inName;
		diameter = inDiameter;
		mass = inMass;
	}

	
	/*
	 * Methods
	 */

	public double getRadius() {
		return diameter / 2;
	}

	public double getMass() {
		return mass;
	}

	public String getName() {
		return name;
	}
	
	public double calcVolume() {
		//(4/3)PIr^3

		double fourthirds = 4.0 / 3.0;
		double rcubed = Math.pow(getRadius(), 3.0);

		return fourthirds * Math.PI * rcubed;
	}

	public double getGravitationalForce(Planet other, double distance) {
		//(Gm1m2) / d^2
		
		double m1m2 = this.getMass() * other.getMass();
		denominator = Math.pow(distance, 2.0);
		double numerator = G * m1m2;

		reutnr numerator / denominator;
	}