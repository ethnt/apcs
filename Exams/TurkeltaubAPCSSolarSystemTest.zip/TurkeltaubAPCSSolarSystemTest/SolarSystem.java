/**
	Java representation of a solar system.
	author: Ethan Turkeltaub
	version: 0.1.0
**/

public class SolarSystem {

	/*
	 * Instance variables
	 */

	private Planet planet1;
	private Planet planet2;
	private Planet planet3;


	/*
	 * Constructors
	 */

	public SolarSystem() {
		planet1 = new Planet();
		planet2 = new Planet("Mars", 6792.0, 0.642E24);
		planet3 = new Planet("Pluto", 2390.0, 0.0125E24);
	}

	public SolarSystem(Planet one, Planet two, Planet three) {
		planet1 = one;
		planet2 = two;
		planet3 = three;
	}

	/*
	 * Methods
	 */

	public Planet getHeaviestPlanet() {
		if (planet1.getMass() > planet2.getMass() && planet1.getMass() > planet3.getMass()) {
			return planet1;
		}

		else if (planet2.getMass() > planet1.getMass() && planet2.getMass() > planet3.getMass()) {
			return planet2;
		}
		
		else {
			return planet3;
		}
	}

	public boolean hasEqualSize(Planet one, Planet two) {
		double diff = one.calcVol() - two.calcVol();

		if (diff < 0.00000001) {
			return true;
		}

		else {
			return false;
		}
	}

	public double getForceBetweenPlanet1andPlanet2() {
		return planet1.getGravitationalForce(planet2, 1000.0);
	}
}